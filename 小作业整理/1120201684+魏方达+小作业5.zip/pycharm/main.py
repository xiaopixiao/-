
import plotCompareHistForActivities
import plotAccelerationColouredByActivity
import hpfilter
import scipy.io as scio
import scipy.signal as sg
import numpy as np
acc=scio.loadmat('./data/acc.mat')['acc']
actid=scio.loadmat('./data/actid.mat')['actid']
t=scio.loadmat('./data/t.mat')['t']
plotCompareHistForActivities.plotCompareHistForActivities(acc, actid,'Walking', 'WalkingUpstairs')
b,a=hpfilter.hpfilter()

ab=sg.filtfilt(b,a,acc,axis=0)
plotAccelerationColouredByActivity.plotAccelerationColouredByActivity(t,np.hstack((acc,ab)),actid,['Original','High-pass filtered'])

