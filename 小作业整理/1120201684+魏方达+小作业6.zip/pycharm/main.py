
import plotCompareHistForActivities
import plotAccelerationColouredByActivity
import hpfilter
import pwelch
import plotPSDActivityComparisonForSubject
import getRawAcceleration
import plotPSDForGivenActivity
import scipy.io as scio
import scipy.signal as sg
import numpy as np
import skimage.measure as sm
import matplotlib.pyplot as plt
acc,actid,t=getRawAcceleration.getRawAcceleration('total',1,'x',50)




plotCompareHistForActivities.plotCompareHistForActivities(acc, actid,'Walking', 'WalkingUpstairs')
b,a=hpfilter.hpfilter()

ab=sg.filtfilt(b,a,acc,axis=0)
plotAccelerationColouredByActivity.plotAccelerationColouredByActivity(t,np.hstack((acc,ab)),actid,['Original','High-pass filtered'])
#以下为作业6
walking=1
a=np.where(actid==walking,1,0)
b=np.where(t<250,1,0)
sel=np.multiply(a,b)
tw=t[np.flatnonzero(sel)]
abw=ab[np.flatnonzero(sel)]
plotAccelerationColouredByActivity.plotAccelerationColouredByActivity(tw,abw,[],['walking'])

f,p=pwelch.pwelch(abw,50)
plt.plot(f,20*np.log10(p))
plt.title('Welch Power Spectral Density Estimate')
plt.ylabel('Power/frequency (dB/Hz)')
plt.xlabel('Frequency (Hz)')
plt.show()


plotPSDActivityComparisonForSubject.plotPSDActivityComparisonForSubject(1,'Walking','WalkingUpstairs')


plotPSDForGivenActivity.plotPSDForGivenActivity(walking)