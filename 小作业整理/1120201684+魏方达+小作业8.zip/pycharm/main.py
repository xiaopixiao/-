
import plotCompareHistForActivities
import plotAccelerationColouredByActivity
import hpfilter
import pwelch
import plotPSDActivityComparisonForSubject
import getRawAcceleration
import plotCorrActivityComparisonForSubject
import featuresFromBuffer
import addActivityLegend
import plotPSDForGivenActivity
import plotAccelerationBufferAndPrediction

import scipy.signal as sg
import scipy.io as scio
import numpy as np
import math

import matplotlib.pyplot as plt
import os
import neurolab as nl
import sklearn.model_selection as sd
import pretty_confusion_matrix.pretty_confusion_matrix as pp
# acc,actid,t=getRawAcceleration.getRawAcceleration('total',1,'x',50)
# feat=np.zeros((1,66))
#
#
# feat[0,1:3]=[1,1]
#
#
#
# plotCompareHistForActivities.plotCompareHistForActivities(acc, actid,'Walking', 'WalkingUpstairs')
# b,a=hpfilter.hpfilter()
#
# ab=sg.filtfilt(b,a,acc,axis=0)
# plotAccelerationColouredByActivity.plotAccelerationColouredByActivity(t,np.hstack((acc,ab)),actid,['Original','High-pass filtered'])
# # #以下为作业6
# walking=1
# a=np.where(actid==walking,1,0)
# b=np.where(t<250,1,0)
# sel=np.multiply(a,b)
# tw=t[np.flatnonzero(sel)]
# abw=ab[np.flatnonzero(sel)]
# plotAccelerationColouredByActivity.plotAccelerationColouredByActivity(tw,abw,[],['walking'])
#
# f,p=pwelch.pwelch(abw,fs=50,w='boxcar',length=1024)
# plt.plot(f,p)
# plt.title('Welch Power Spectral Density Estimate')
# plt.ylabel('Power/frequency (dB/Hz)')
# plt.xlabel('Frequency (Hz)')
# plt.show()
#
#
# plotPSDActivityComparisonForSubject.plotPSDActivityComparisonForSubject(1,'Walking','WalkingUpstairs')
#
#
# plotPSDForGivenActivity.plotPSDForGivenActivity(walking)
# # 以下为作业7
#
# locs,_=sg.find_peaks(p)
# plt.plot(f,20*np.log10(p))
# plt.plot(f[locs],20*np.log10(p[locs]),'rs')
# plt.grid()
# addActivityLegend.addActivityLegend(np.array([1]))
# plt.title('Power Spectral Density with Peaks Estimates')
# plt.xlabel('Frequency (Hz)')
# plt.ylabel('Power/Frequency (dB/Hz)')
# plt.show()
#
#
# fmindist = 0.25
# N = 2*(len(f)-1)
# fs=50
# minpkdist = math.floor(fmindist/(fs/N))
# locs,_=sg.find_peaks(p,distance=minpkdist,prominence=0.15)
# locs=locs[np.argpartition(f[locs], 8)[:8]]
# plt.plot(f,20*np.log10(p))
# plt.plot(f[locs],20*np.log10(p[locs]),'rs')
# plt.grid()
# addActivityLegend.addActivityLegend(np.array([1]))
# plt.title('Power Spectral Density with Peaks Estimates')
# plt.xlabel('Frequency (Hz)')
# plt.ylabel('Power/Frequency (dB/Hz)')
# plt.show()
#
#
#
# abw=np.array(abw).flatten()
# c=np.correlate(abw,abw,mode='full')
# lags=np.arange(-(len(abw)-1),len(abw))
# tmindist = 0.3
# minpkdist = np.floor(tmindist/(1/fs))
# locs,_= sg.find_peaks(c,prominence=1e4,distance=minpkdist)
# tc = (1/fs)*lags
# plt.plot(tc,c)
# plt.plot(tc[locs],c[locs],'rs')
# plt.grid()
# plt.xlim(-5,5)
# addActivityLegend.addActivityLegend(np.array([1]))
# plt.title('Autocorrrelation with Peaks Estimates')
# plt.xlabel('Time lag (s)')
# plt.ylabel('Correlation')
# plt.show()
#
#
#
# plotCorrActivityComparisonForSubject.plotCorrActivityComparisonForSubject(1, 'WalkingUpstairs', 'WalkingDownstairs')


# 以下为小作业8

featureExtractionFcn = 'featuresFromBuffer.py'
dirs=os.path.join('./',featureExtractionFcn)
if not os.path.exists(dirs):
    os.makedirs(dirs)

file = open(dirs)
count = len(file.readlines())
print('\n%d lines of source code found in %s\n'% (count,featureExtractionFcn))
file.close()

# [globals().pop(var) for var in dir() if not var.startswith("__")]
buf=scio.loadmat('./data/BufferFeatures.mat')

bufa=scio.loadmat('./data/BufferedAccelerations.mat')






X=buf['feat'].transpose()
actid=bufa['actid']
atx=bufa['atx']
aty=bufa['aty']
atz=bufa['atz']
actnames=bufa['actnames']
t=bufa['t']
n = np.max(actid)
tgtall = (actid.T[:, None, :] == np.arange(1, n+1)[:, None]).astype(np.int)
tgtall=tgtall[0].transpose()
min_value=np.min(X,axis=1).reshape(-1,1)
max_value=np.max(X,axis=1).reshape(-1,1)



p=np.concatenate((min_value, max_value), axis=1)
X=X.transpose()
net=nl.net.newff(p,[18,6],[nl.net.trans.TanSig(),nl.net.trans.PureLin()])
net.trainf = nl.net.train.train_ncg

# X,tgtall,epochs=151,show=1,goal=0.01
net.train(X,tgtall,epochs=10,show=1,goal=0.01)

predicted_output=net.sim(X[0,:].reshape(1,-1))

for k in range(0,np.size(atx,0)):
    ax = atx[k,:]
    ay = aty[k,:]
    az = atz[k,:]
    f = featuresFromBuffer.featuresFromBuffer(ax, ay, az, 50)
    scores=net.sim(f)
    maxidx = np.argmax(scores)
    estimatedActivity = actnames[0,maxidx]
    actualActivity = actnames[0,actid[k,0]-1]
    plotAccelerationBufferAndPrediction.plotAccelerationBufferAndPrediction(ax, ay, az, t, actualActivity, estimatedActivity)




trainInd,uu,trainInd_la,uu_la=sd.train_test_split(X,tgtall,test_size=0.3)
valInd,testInd,valInd_la,testInd_la=sd.train_test_split(uu,uu_la,test_size=0.5)

scoreval = net.sim(testInd)
scoreval = np.argmax(scoreval,1)+1
uk=np.argmax(testInd_la,1)+1




pp.pp_matrix_from_data(uk,scoreval, columns=range(1, 7))
