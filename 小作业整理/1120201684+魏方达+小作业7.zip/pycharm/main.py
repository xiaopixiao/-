
import plotCompareHistForActivities
import plotAccelerationColouredByActivity
import hpfilter
import pwelch
import plotPSDActivityComparisonForSubject
import getRawAcceleration
import plotCorrActivityComparisonForSubject

import addActivityLegend
import plotPSDForGivenActivity

import scipy.signal as sg
import numpy as np
import math

import matplotlib.pyplot as plt
acc,actid,t=getRawAcceleration.getRawAcceleration('total',1,'x',50)

plotCompareHistForActivities.plotCompareHistForActivities(acc, actid,'Walking', 'WalkingUpstairs')
b,a=hpfilter.hpfilter()

ab=sg.filtfilt(b,a,acc,axis=0)
plotAccelerationColouredByActivity.plotAccelerationColouredByActivity(t,np.hstack((acc,ab)),actid,['Original','High-pass filtered'])
# #以下为作业6
walking=1
a=np.where(actid==walking,1,0)
b=np.where(t<250,1,0)
sel=np.multiply(a,b)
tw=t[np.flatnonzero(sel)]
abw=ab[np.flatnonzero(sel)]
plotAccelerationColouredByActivity.plotAccelerationColouredByActivity(tw,abw,[],['walking'])

f,p=pwelch.pwelch(abw,50)
plt.plot(f,20*np.log10(p))
plt.title('Welch Power Spectral Density Estimate')
plt.ylabel('Power/frequency (dB/Hz)')
plt.xlabel('Frequency (Hz)')
plt.show()


plotPSDActivityComparisonForSubject.plotPSDActivityComparisonForSubject(1,'Walking','WalkingUpstairs')


plotPSDForGivenActivity.plotPSDForGivenActivity(walking)
# 以下为作业7

locs,_=sg.find_peaks(p)
plt.plot(f,20*np.log10(p))
plt.plot(f[locs],20*np.log10(p[locs]),'rs')
plt.grid()
addActivityLegend.addActivityLegend(np.array([1]))
plt.title('Power Spectral Density with Peaks Estimates')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Power/Frequency (dB/Hz)')
plt.show()


fmindist = 0.25
N = 2*(len(f)-1)
fs=50
minpkdist = math.floor(fmindist/(fs/N))
locs,_=sg.find_peaks(p,distance=minpkdist,prominence=0.15)
locs=locs[np.argpartition(f[locs], 8)[:8]]
plt.plot(f,20*np.log10(p))
plt.plot(f[locs],20*np.log10(p[locs]),'rs')
plt.grid()
addActivityLegend.addActivityLegend(np.array([1]))
plt.title('Power Spectral Density with Peaks Estimates')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Power/Frequency (dB/Hz)')
plt.show()



abw=np.array(abw).flatten()
c=np.correlate(abw,abw,mode='full')
lags=np.arange(-(len(abw)-1),len(abw))
tmindist = 0.3
minpkdist = np.floor(tmindist/(1/fs))
locs,_= sg.find_peaks(c,prominence=1e4,distance=minpkdist)
tc = (1/fs)*lags
plt.plot(tc,c)
plt.plot(tc[locs],c[locs],'rs')
plt.grid()
plt.xlim(-5,5)
addActivityLegend.addActivityLegend(np.array([1]))
plt.title('Autocorrrelation with Peaks Estimates')
plt.xlabel('Time lag (s)')
plt.ylabel('Correlation')
plt.show()



plotCorrActivityComparisonForSubject.plotCorrActivityComparisonForSubject(1, 'WalkingUpstairs', 'WalkingDownstairs')


