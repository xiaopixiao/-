import scipy.signal as sg
import matplotlib.pyplot as plt
import numpy as np
def pwelch(x,fs):
    f,p=sg.welch(x[:,0],fs,nperseg=1024)
    return f,p
